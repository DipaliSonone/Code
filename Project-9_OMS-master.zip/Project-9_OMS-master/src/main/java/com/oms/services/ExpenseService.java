package com.oms.services;

import com.oms.Entity.Expense;
import com.oms.dto.ClientDTO;
import com.oms.dto.ExpenseDTO;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;


public interface ExpenseService {
    String addExpense(ExpenseDTO expenseDTO);

    Optional<Object> getExpenseById(Integer expenseId);

    String deleteExpenseById(Integer expenseId);

    Object updateExpense(ExpenseDTO expenseDTO , Integer expenseId);

    ExpenseDTO updateExpense(ExpenseDTO expenseDTO);
    List<ExpenseDTO> getAllExpense();


    Object toExpenseDto(Expense expense);
}
