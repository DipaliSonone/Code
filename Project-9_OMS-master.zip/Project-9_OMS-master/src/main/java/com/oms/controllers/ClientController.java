package com.oms.controllers;

import com.oms.dto.ClientDTO;
import com.oms.dto.ExpenseDTO;
import com.oms.exceptions.ClientAlreadyExistException;
import com.oms.exceptions.ClientNotFoundException;
import com.oms.services.ClientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/client")
public class ClientController {
    @Autowired
    private ClientService clientService;

    @PostMapping("/addClient")
    public ResponseEntity<String>addClient(@RequestBody ClientDTO clientDTO){

        try {
            String s = clientService.addClient(clientDTO);
            return ResponseEntity.status(HttpStatus.OK).body(s);
        }catch (ClientAlreadyExistException clientAlreadyExistException){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Client Already Exist");
        }
    }
    @GetMapping("/get/{clientId}")
    public ResponseEntity<Optional<Object>> showClient(@PathVariable("clientId") Integer clientId) {
        try {
            Optional<Object> clientById = Optional.ofNullable(this.clientService.getClientById(clientId));
            if (clientById.isPresent()) {
                return ResponseEntity.ok(clientById);
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Optional.empty());
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Optional.empty());
        }
    }

    @PutMapping("/update-client/{clientId}")
    public ResponseEntity<String> updateClient(@RequestBody ClientDTO clientDTO, @PathVariable("clientId") Integer clientId) {
        try {
            this.clientService.updateClient(clientDTO, clientId);
            return ResponseEntity.ok("Client updated successfully.");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to update project: " + e.getMessage());
        }
    }

    @DeleteMapping("/delete/{clientId}")
    public ResponseEntity<String> deleteClient(@PathVariable("clientId") Integer clientId) {
        try {
            this.clientService.deleteClientById(clientId);
            return ResponseEntity.ok("Client deleted successfully.");
        } catch (Exception | ClientNotFoundException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to delete client: " + e.getMessage());
        }
    }

    @GetMapping("/get-all")
    public ResponseEntity<List<ClientDTO>> showAllClients() {
        try {
            List<ClientDTO> allClients = this.clientService.getAllClients();
            return ResponseEntity.ok(allClients);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }
}
