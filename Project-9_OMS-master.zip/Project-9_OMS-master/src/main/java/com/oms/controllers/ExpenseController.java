package com.oms.controllers;

import com.oms.dto.ExpenseDTO;
import com.oms.services.ExpenseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/expense")
public class ExpenseController {
    @Autowired
    private ExpenseService expenseService;

    @PostMapping("/add-expensee")
    public ResponseEntity<String> addExpense(@RequestBody ExpenseDTO expenseDTO) {
        try {
            this.expenseService.addExpense(expenseDTO);
        }catch(Exception e){
           e.getMessage();
        }
        return new ResponseEntity<>("Expense added successfully", HttpStatus.OK);
    }
    @GetMapping("/get/{expenseId}")
    public ResponseEntity<Optional<Object>> showExpense(@PathVariable("expenseId") Integer expenseId) {
        try {
            Optional<Object> expenseById = this.expenseService.getExpenseById(expenseId);
            if (expenseById.isPresent()) {
                return ResponseEntity.ok(expenseById);
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Optional.empty());
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Optional.empty());
        }
    }

    @PutMapping("/update-expense/{expenseId}")
    public ResponseEntity<String> updateExpense(@RequestBody ExpenseDTO expenseDTO, @PathVariable("expenseId") Integer expenseId) {
        try {
            this.expenseService.updateExpense(expenseDTO, expenseId);
            return ResponseEntity.ok("Project updated successfully.");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to update project: " + e.getMessage());
        }
    }

    @DeleteMapping("/delete/{expenseid}")
    public ResponseEntity<String> deleteExpense(@PathVariable("expenseId") Integer expenseid) {
        try {
            this.expenseService.deleteExpenseById(expenseid);
            return ResponseEntity.ok("Project deleted successfully.");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to delete project: " + e.getMessage());
        }
    }

    @GetMapping("/get-all")
    public ResponseEntity<List<ExpenseDTO>> showAllExpenses() {
        try {
            List<ExpenseDTO> allProjects = this.expenseService.getAllExpense();
            return ResponseEntity.ok(allProjects);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }
}

