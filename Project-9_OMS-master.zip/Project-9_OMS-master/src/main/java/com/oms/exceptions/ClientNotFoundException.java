package com.oms.exceptions;

public class ClientNotFoundException extends Throwable {
    public ClientNotFoundException(String clientNotFound) {
        super();
    }

}
