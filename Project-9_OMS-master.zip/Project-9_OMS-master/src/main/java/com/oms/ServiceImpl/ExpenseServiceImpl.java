package com.oms.ServiceImpl;

import com.oms.Entity.Expense;
import com.oms.dto.ExpenseDTO;
import com.oms.exceptions.ExpenseNotFoundException;
import com.oms.repositories.ExpenseRepository;
import com.oms.services.ExpenseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service
public class ExpenseServiceImpl implements ExpenseService {
    @Autowired
    private ExpenseRepository expenseRepository;
    @Override
    public String addExpense(ExpenseDTO expenseDTO) {
        Expense expense = dtoToEntity(expenseDTO);
        //try {
           // if (expenseDTO == null) {
                this.expenseRepository.save(expense);
                return "success";
            //} else {

            }
       // } catch (ExpenseAlreadyExistException e){
       //     throw new ExpenseAlreadyExistException("Expense already exist");
   // }

      //  return null;
   // }

    @Override
    public Optional<Object> getExpenseById(Integer expenseId) {
        try {
            Expense expense = this.expenseRepository.findById(expenseId)
                    .orElseThrow(() -> new ExpenseNotFoundException("Expense Not Found"));
            return Optional.ofNullable((Expense) this.toExpenseDto(expense));
        } catch (Exception e) {
            return Optional.empty();
        }
     }



    @Override
    public String deleteExpenseById(Integer expenseId) {
            Optional<Expense> byId = expenseRepository.findById(expenseId);
            if (byId.isPresent()){
                expenseRepository.deleteById(expenseId);
                return "Expense deleted successfully";
            }else {
                throw new ExpenseNotFoundException("Expense Not Found ");
            }
        }

    @Override
    public Expense updateExpense(ExpenseDTO expenseDTO, Integer expenseId) {
        try {
            Expense expense = expenseRepository.findById(expenseId).orElse(null);

            if (expense != null) {

                expense.setAmount(expenseDTO.getAmount());
                expense.setCategory(expenseDTO.getCategory());
                expense.setDate(expenseDTO.getDate());
                expense.setDescription(expenseDTO.getDescription());
                expense.setName(expenseDTO.getName());
                expense.setPaidBy(expenseDTO.getPaidBy());
                expense.setPaymentType(expenseDTO.getPaymentType());
                expense.setUserId(expenseDTO.getUserId());
                expense.setExpensecol(expenseDTO.getExpensecol());

                expenseRepository.save(expense);
            }
        } catch (Exception e) {

        }
        return null;
    }

    @Override
    public ExpenseDTO updateExpense(ExpenseDTO expenseDTO) {
        return null;
    }


    @Override
    public List<ExpenseDTO> getAllExpense() {
        return null;
    }

    @Override
    public Object toExpenseDto(Expense expense) {
        return null;
    }

    public ExpenseDTO entityToExpenseDto(Expense expense){
        ExpenseDTO expenseDTO=new ExpenseDTO();

        expenseDTO.setAmount(expense.getAmount());
        expenseDTO.setCategory(expense.getCategory());
        expenseDTO.setDate(expense.getDate());
        expenseDTO.setDescription(expense.getDescription());
        expenseDTO.setName(expense.getName());
        expenseDTO.setPaidBy(expense.getPaidBy());
        expenseDTO.setPaymentType(expense.getPaymentType());
        expenseDTO.setUserId(expense.getUserId());
        expenseDTO.setExpensecol(expense.getExpensecol());

        return  expenseDTO;
    }

    public Expense dtoToEntity(ExpenseDTO expenseDTO){
        Expense expense=new Expense();

        expense.setAmount(expenseDTO.getAmount());
        expense.setCategory(expenseDTO.getCategory());
        expense.setDate(expenseDTO.getDate());
        expense.setDescription(expenseDTO.getDescription());
        expense.setName(expenseDTO.getName());
        expense.setPaidBy(expenseDTO.getPaidBy());
        expense.setPaymentType(expenseDTO.getPaymentType());
        expense.setUserId(expenseDTO.getUserId());
        expense.setExpensecol(expenseDTO.getExpensecol());

        return expense;
    }

}
