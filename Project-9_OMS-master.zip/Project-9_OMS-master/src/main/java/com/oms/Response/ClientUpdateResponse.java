package com.oms.Response;

import com.oms.dto.ClientDTO;
import lombok.Data;

@Data
public class ClientUpdateResponse {

    private String message;
    private String status;
    private String exception;
    private ClientDTO response;

    public ClientUpdateResponse(String message) {
        this.message = message;
    }
}
