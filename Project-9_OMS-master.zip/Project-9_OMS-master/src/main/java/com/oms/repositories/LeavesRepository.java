package com.oms.repositories;

import com.oms.Entity.Leaves;
import org.springframework.data.jpa.repository.JpaRepository;


public interface LeavesRepository extends JpaRepository<Leaves, Integer> {
}
