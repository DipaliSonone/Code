package com.oms.repositories;

import com.oms.Entity.AddAssessment;
import org.springframework.data.jpa.repository.JpaRepository;


public interface AddAssessmentRepository extends JpaRepository<AddAssessment, Integer> {
}
